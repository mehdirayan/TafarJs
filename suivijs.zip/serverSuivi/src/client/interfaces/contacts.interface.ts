export interface IContacts {
  nom: string;
  téléphone: string;
  email: string;
}
