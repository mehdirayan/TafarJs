export enum eEtat {
    nonCommence = "Non Commencée",
    enCours = "En Cours",
    achevée = "Achevée",
    livré="livré",
    terminée = "Terminée"
  
  }
  export enum eTest {
    pasFini = "Pas Fini",
    abandonée="Pas réparable",
    aTester="A tester chez le client",
    ok = "Test OK"
  }